#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

int main(void){
	TpRBtree *tree = inicializa();
	int valor, op = 1;

	while(op != 0){
		op = menu();
		switch(op){
			case 1:	printf("Digite a chave: ");
					scanf("%d", &valor);
					printf("\n");
					tree = inserir(tree, tree->sentry, valor);
					atualizaNivel(tree->sentry, 1); break;
			case 2: listaDados(tree->sentry);
					printf("\n"); break;
			case 0: destroiArvore(tree->sentry);
					free(tree); break;
			default : printf("Opcao invalida!\n"); break;
		}
	}
}
