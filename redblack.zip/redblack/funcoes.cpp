#include <stdio.h>
#include <stdlib.h>

//RED   =  0
//Black =  1

typedef struct node{ //
	int chave, nivel, cor;
	struct node *left;
	struct node *right;
	struct node *dad;
} TpNode;

typedef struct _rbtree{
	TpNode *raiz;
	TpNode *sentry; // sentinela da arvore
} TpRBtree;

TpRBtree* inicializa(){
	TpRBtree *arvore = (TpRBtree*)malloc(sizeof(TpRBtree));
	TpNode *sentry = (TpNode*)malloc(sizeof(TpNode));
	arvore->raiz = NULL;
	arvore->sentry = sentry;
	arvore->sentry->nivel = 1;
	arvore->sentry->chave = -1;
	arvore->sentry->cor = 1;
	arvore->sentry->dad = NULL;
	arvore->sentry->left = NULL;
	arvore->sentry->right = NULL;
	return arvore;
}

bool verificaKey(TpNode *nodo, int key){
	TpNode *t = nodo;
	while(t != NULL){
		if(key == t->chave) return true;
		else if(key > t->chave) t = t->right;
		else if(key < t->chave) t = t->left;
	}
	return false;
}

TpNode* rightRotation(TpNode *nodo){
	TpNode *aux = nodo->left;
	aux->dad = nodo->dad;
	nodo->dad = aux;
	nodo->left = aux->right;
	if(aux->right != NULL) aux->right->dad = nodo;
	aux->right = nodo;
	if(aux->dad != NULL){
		aux = aux->dad;
		aux->left = nodo->dad;
	}
	return aux;
}

TpNode* leftRotation(TpNode *nodo){
	TpNode *aux = nodo->right;
	aux->dad = nodo->dad;
	nodo->dad = aux;
	nodo->right = aux->left;
	if(aux->left != NULL) aux->left->dad = nodo;
    aux->left = nodo;
    if(aux->dad != NULL){
    	aux = aux->dad;
		aux->right = nodo->dad;
    }
    return aux;
}

TpRBtree* verificaRubroNegra(TpRBtree *arvore, TpNode *nodo, int key){
	if(key == arvore->sentry->chave) return arvore;
	else if(arvore->sentry->left != NULL && key == arvore->sentry->left->chave) return arvore;
	else if(arvore->sentry->right != NULL && key == arvore->sentry->right->chave) return arvore;

	TpNode *t = nodo;
	TpNode *tDad = t->dad;
	TpNode *tAvo = tDad->dad;
	TpNode *aux;

	if(tDad->chave < tAvo->chave){ //pai é filho a esquerda
		if(t->chave < tDad->chave){ //nodo é filho a esquerda
			if(tDad->cor == 0){//se o pai do nodo é vermelho
				if(tAvo->right == NULL || tAvo->right->cor == 1){//se o tio é nulo ou preto
					if(tAvo->chave == arvore->sentry->chave){//se o avo é a raiz
						arvore->sentry = tDad;
						arvore->raiz = arvore->sentry;
						if(tDad->cor == 0) tDad->cor = 1;
						else tDad->cor = 0;
						if(tAvo->cor == 0) tAvo->cor = 1;
						else tAvo->cor = 0;
						aux = rightRotation(tAvo);
						arvore = verificaRubroNegra(arvore, aux, aux->chave);
						if(arvore->raiz->cor == 0) arvore->raiz->cor = 1;
						return arvore;
					}else{
						if(tDad->cor == 0) tDad->cor = 1;
						else tDad->cor = 0;
						if(tAvo->cor == 0) tAvo->cor = 1;
						else tAvo->cor = 0;
						aux = rightRotation(tAvo);
						arvore = verificaRubroNegra(arvore, aux, aux->chave);
						if(arvore->raiz->cor == 0) arvore->raiz->cor = 1;
						return arvore;
					}
				}else if(tAvo->right->cor == 0){//se o tio é vermelho
					if(tDad->cor == 0) tDad->cor = 1;
					else tDad->cor = 0;
					if(tAvo->cor == 0) tAvo->cor = 1;
					else tAvo->cor = 0;
					tAvo->right->cor = 1;
					arvore = verificaRubroNegra(arvore, tAvo, tAvo->chave);
					if(arvore->raiz->cor == 0) arvore->raiz->cor = 1;
					return arvore;
				}
			}else return arvore;
		}else if(t->chave > tDad->chave){//nodo é filho a direita
			if(tDad->cor == 0){
				t->dad = tAvo;
				tDad->dad = t;
				tAvo->left = t;
				tDad->right = NULL;
				t->left = tDad;
				arvore = verificaRubroNegra(arvore, tDad, tDad->chave);
				return arvore;
		}
  }else return arvore;
}else if(tDad->chave > tAvo->chave){//pai é filho a direita
		if(t->chave > tDad->chave){//nodo é filho e direita
			if(tDad->cor == 0){//se o pai é vermelho
				if(tAvo->left == NULL || tAvo->left->cor == 1){//se o tio é nulo ou preto
					if(tAvo->chave == arvore->sentry->chave){//se o avo é a raiz
						arvore->sentry = tDad;
						arvore->raiz = arvore->sentry;
						if(tDad->cor == 0) tDad->cor = 1;
						else tDad->cor = 0;
						if(tAvo->cor == 0) tAvo->cor = 1;
						else tAvo->cor = 0;
						aux = leftRotation(tAvo);
						arvore = verificaRubroNegra(arvore, aux, aux->chave);
						if(arvore->raiz->cor == 0) arvore->raiz->cor = 1;
						return arvore;
					}else{
						if(tDad->cor == 0) tDad->cor = 1;
						else tDad->cor = 0;
						if(tAvo->cor == 0) tAvo->cor = 1;
						else tAvo->cor = 0;
						aux = leftRotation(tAvo);
						arvore = verificaRubroNegra(arvore, aux, aux->chave);
						if(arvore->raiz->cor == 0) arvore->raiz->cor = 1;
						return arvore;
					}
				}else if(tAvo->left->cor == 0){//se o tio é vermelho
					if(tDad->cor == 0) tDad->cor = 1;
					else tDad->cor = 0;
					if(tAvo->cor == 0) tAvo->cor = 1;
					else tAvo->cor = 0;
					tAvo->left->cor = 1;
					arvore = verificaRubroNegra(arvore, tAvo, tAvo->chave);
					if(arvore->raiz->cor == 0) arvore->raiz->cor = 1;
					return arvore;
				}
			}else return arvore;
		}else if(t->chave < tDad->chave){//nodo é filho a esquerda
			if(tDad->cor == 0){
				t->dad = tAvo;
				tDad->dad = t;
				tAvo->right = t;
				tDad->left = NULL;
				t->right = tDad;
				arvore = verificaRubroNegra(arvore, tDad, tDad->chave);
				return arvore;
			}else return arvore;
		}
	}
}

TpRBtree* inserir(TpRBtree *arvore, TpNode *nodo, int key){
	TpRBtree *a = arvore;
	TpNode *t = nodo;

	if(a->raiz == NULL){
		a->raiz = a->sentry;//cria uma sentinela da raiz
		a->sentry->chave = key;
		return a;
	}
	if(!verificaKey(t, key)){
		if(key < t->chave){
			if(t->left != NULL) a = inserir(a, t->left, key);
			else{
				TpNode *novo = (TpNode*)malloc(sizeof(TpNode));
				t->left = novo;
				novo->nivel = 1;
				novo->chave = key;
				novo->cor = 0;
				novo->dad = t;
				novo->left = NULL;
				novo->right = NULL;
				a = verificaRubroNegra(a, novo, novo->chave); // para localizar o local certo para colocar o nodo
				return a;
			}
		}
		else if(key > t->chave){
			if(t->right != NULL) a = inserir(a, t->right, key);
			else{
				TpNode *novo = (TpNode*)malloc(sizeof(TpNode));
				t->right = novo;
				novo->nivel = 1;
				novo->chave = key;
				novo->cor = 0;
				novo->dad = t;
				novo->left = NULL;
				novo->right = NULL;
				a = verificaRubroNegra(a, novo, novo->chave);
				return a;
			}
		}
	}else{
		printf("<<Esta chave ja foi inserida!>>\n\n");
		return a;
	}
}

char obterCor(TpNode *nodo){
	if(nodo->cor == 1) return 'b';
	else if(nodo->cor == 0) return 'v';
}

int obterPai(TpNode *nodo){
	if(nodo->dad == NULL) return 0; //caso nao tenha pai - (raiz)
	else if(nodo->dad != NULL) return nodo->dad->chave;
}

void listaDados(TpNode *nodo){
	printf("-> %d Nivel[%d] Pai[%d] %c\n", nodo->chave, nodo->nivel, obterPai(nodo), obterCor(nodo));
	if(nodo->left != NULL) listaDados(nodo->left);
	if(nodo->right != NULL) listaDados(nodo->right);
}

void destroiArvore(TpNode *nodo){//free todos os nodos em pos-order
	TpNode *t = nodo;
	if(t->left != NULL) destroiArvore(t->left);
	if(t->right != NULL) destroiArvore(t->right);
	free(t);
}

void atualizaNivel(TpNode *nodo, int level){
	TpNode *t = nodo;
	t->nivel = level;
	if(t->left != NULL) atualizaNivel(t->left, level + 1);
	if(t->right != NULL) atualizaNivel(t->right, level + 1);
}

int menu(){
	int op;
	printf("Árvore RedBlack\n\n 1-Inserir valor\n 2-Listar elementos\n 0-Sair\n");
	scanf("%d", &op);
	return op;
}
