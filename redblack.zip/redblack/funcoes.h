#include "funcoes.cpp"

TpRBtree* inicializa();
TpRBtree* inserir(TpRBtree *arvore, TpNode *nodo, int key);
void listaDados(TpNode *nodo);
void destroiArvore(TpNode *nodo);
void atualizaNivel(TpNode *nodo, int level);
int menu();
